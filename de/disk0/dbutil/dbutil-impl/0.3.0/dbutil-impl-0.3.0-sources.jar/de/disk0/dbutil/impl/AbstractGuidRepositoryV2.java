package de.disk0.dbutil.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.StringUtils;

import de.disk0.dbutil.api.IdGeneratorClass;
import de.disk0.dbutil.api.IdGenerator;
import de.disk0.dbutil.api.entities.BaseGuidEntityV2;
import de.disk0.dbutil.api.exceptions.SqlException;
import de.disk0.dbutil.api.utils.IdGeneratorGuid;
import de.disk0.dbutil.impl.util.SqlLog;

public abstract class AbstractGuidRepositoryV2<T extends BaseGuidEntityV2> extends AbstractRepository<T,String> implements RowMapper<T> {

	private static Log log = LogFactory.getLog(AbstractGuidRepositoryV2.class);

	private IdGenerator idGenerator;
	
	 public void setIdGenerator(IdGenerator idGenerator) {
	        assert idGenerator != null;
	        this.idGenerator = idGenerator;
	 }
	 
	public String generateId() throws SqlException {
		if(idGenerator!=null) return idGenerator.generateId();
		try {
			log.info("instantiating GUID generator ... ");
			IdGenerator idg = null;
			Class<? extends IdGenerator> ggc = null;
			IdGeneratorClass gc = this.getClass().getAnnotation(IdGeneratorClass.class);
			if(gc!=null) {
				log.info("instantiating GUID generator ... annotation: "+gc.value());
				ggc = gc.value();
			}
			if(ggc!=null) {
				log.info("instantiating GUID generator ... instance: "+gc.value());
				idg = ggc.getDeclaredConstructor().newInstance();
			}
			if(idg == null) {
				idg = new IdGeneratorGuid();
			}
			log.info("instantiating GUID generator ... result: "+idg);
			idGenerator = idg;
			return idGenerator.generateId();
		} catch (Exception e) {
			log.warn("unable to instantiate id generator: ",e);
			throw new SqlException("unable to instantiate id generator", e);
		}
	}


	public int delete(String id) throws SqlException {
		T t = get(id);
		return super.delete(t);
	}

	public T save(T t) throws SqlException {
		return save(t,generateId());
	}
	
	public T save(T t, String uuid) throws SqlException {
		NamedParameterJdbcTemplate templ = null;
		try {
			beforeSave(t);
			templ = getTemplate();
			if(!StringUtils.hasLength(t.getId())) {
				t.setId(uuid);
				String sql = getInsertOneStatement();
				
				MapSqlParameterSource params = unmapInsert(t);
				if(log.isDebugEnabled()) {
					log.debug("saving entity: insert! ("+getClazz().getSimpleName()+")");
					log.debug("INSERT: "+sql);
					log.debug("INSERT: "+SqlLog.names(params.getValues()));
				}
				SqlLog.values(getClazz().getSimpleName(), params.getValues());
				try {
					int done = templ.update(sql, params);
					log.debug("saving entity: "+done+" rows inserted");
				} catch (Exception e) {
					log.warn("saving failed: "+sql+" params="+SqlLog.names(params.getValues()));
					throw e;
					
				}
			} else {
				String sql = getUpdateOneStatement();
				MapSqlParameterSource params = unmapUpdate(t);
				if(log.isDebugEnabled()) {
					log.debug("saving entity: update!");
					log.debug("UPDATE: "+sql);
					log.debug("UPDATE: "+SqlLog.names(params.getValues()));
				}
				SqlLog.values(getClazz().getSimpleName(), params.getValues());
				int done;
				try {
					done = templ.update(sql, params);
				} catch (Exception e) {
					log.warn("saving failed: "+sql+" params="+SqlLog.names(params.getValues()));
					throw e;
				}
				if(done < 1) {
					throw new SqlException("expecting row update, but nothing happened", null);
				} else if (done > 1) {
					throw new SqlException("expecting ONE row update, but more than one row was updated", null);
				}
				log.debug("saving entity: "+done+" rows updated");
			}
			log.debug("saving entity: calling after save ... ");
			afterSave(t);
			log.debug("saving entity: calling after save ... done!");
			log.debug("saving entity: retrieving object as saved: ("+getClazz().getSimpleName()+")");
			T out = get(t.getId());
			log.debug("saving entity: retrieving object as saved: "+(out==null?"NULL":"FOUND"));
			return out;
		} catch (Exception e) {
			throw new SqlException("SQL.REPO.SAVE_FAILED",new Object[] { e.getMessage() },  e);
		} finally {
		}
	}	
	
}
